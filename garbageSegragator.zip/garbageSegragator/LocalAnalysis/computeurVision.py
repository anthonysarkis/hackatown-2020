import requests
# If you are using a Jupyter notebook, uncomment the following line.
# %matplotlib inline
import matplotlib.pyplot as plt
from PIL import Image
from io import BytesIO
import json

# Add your Computer Vision subscription key and endpoint to your environment variables.

subscription_key ="1e2e340a1c504495a00246ef42a25461"



endpoint ='https://bigovision.cognitiveservices.azure.com/'

analyze_url = endpoint + "vision/v2.1/analyze"

# Set image_path to the local path of an image that you want to analyze.
image_path = "pomme.jpg"

# Read the image into a byte array
image_data = open(image_path, "rb").read()
headers = {'Ocp-Apim-Subscription-Key': subscription_key,
           'Content-Type': 'application/octet-stream'}
params = {'visualFeatures': 'Description'}
response = requests.post(
    analyze_url, headers=headers, params=params, data=image_data)
response.raise_for_status()

# The 'analysis' object contains various fields that describe the image. The most
# relevant caption for the image is obtained from the 'description' property.
analysis = response.json()
print(analysis)
image_caption = analysis["description"]["captions"][0]["text"].capitalize()

# Display the image and overlay it with the caption.
image = Image.open(BytesIO(image_data))
plt.imshow(image)
plt.axis("off")
_ = plt.title(image_caption, size="x-large", y=-0.1)


dataDict = analysis
#print(dataDict)
#print(dataDict.keys())
importantValues = dataDict["description"]["tags"][0:4]

print(importantValues)

with open("compost.txt", "r+") as f:
    compost = f.readlines()
    compost = [x.lower() for x in compost]
    compost = [x.strip() for x in compost]

with open("landfill.txt", "r+") as f:
    landfill = f.readlines()
    landfill = [x.lower() for x in landfill]
    landfill = [x.strip() for x in landfill]

with open("recyclable.txt", "r+") as f:
    recyclable = f.readlines()
    recyclable = [x.lower() for x in recyclable]
    recyclable = [x.strip() for x in recyclable]

valueCompostable = False
valueRecyclable = False
valueLandfill = False

answer = "This item doesnt belong here"

for value in importantValues:
    for compostableElement in compost:
        if (value == compostableElement):
            valueCompostable = True
            answer = "That item belongs to compost"
            break   
    if(valueCompostable):
        break

    for recyclableElement in recyclable:
        if (value == recyclableElement):
            valueRecyclable = True
            answer = "That item belongs to recycle bin"
            break
    if(valueRecyclable):
        break
    
    for landfillElement in landfill:
        if (value == landfillElement):
            valueLandfill = True
            answer = "That item belongs to the garbage bin"


print(answer)
