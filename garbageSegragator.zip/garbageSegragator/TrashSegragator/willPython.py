import json
dataDict = json.load(open("dataFile.json"))
#print(dataDict)
#print(dataDict.keys())
importantValues = dataDict["description"]["tags"][0:4]

print(importantValues)

with open("compost.txt", "r+") as f:
    compost = f.readlines()
    compost = [x.lower() for x in compost]
    compost = [x.strip() for x in compost]

with open("landfill.txt", "r+") as f:
    landfill = f.readlines()
    landfill = [x.lower() for x in landfill]
    landfill = [x.strip() for x in landfill]

with open("recyclable.txt", "r+") as f:
    recyclable = f.readlines()
    recyclable = [x.lower() for x in recyclable]
    recyclable = [x.strip() for x in recyclable]

valueCompostable = False
valueRecyclable = False
valueLandfill = False

answer = "This item doesnt belong here"

for value in importantValues:
    for compostableElement in compost:
        if (value == compostableElement):
            valueCompostable = True
            answer = "That item belongs to campoost"
            break   
    if(valueCompostable):
        break

    for recyclableElement in recyclable:
        if (value == recyclableElement):
            valueRecyclable = True
            answer = "That item belongs to reCyclaBle"
            break
    if(valueRecyclable):
        break
    
    for landfillElement in landfill:
        if (value == landfillElement):
            valueLandfill = True
            answer = "That item belongs to LAAAAAAndfill"


print(answer)
